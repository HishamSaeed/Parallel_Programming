#include "familytree.h"

int traverse(tree *node, int numThreads){
	
	// TODO implement your solution in here.

    return node->IQ;
}
