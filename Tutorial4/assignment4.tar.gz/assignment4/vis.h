#ifndef VIS_H
#define VIS_H

#include "ds.h"

void visualize();

#endif
