#ifndef FT_REF_H
#define FT_REF_H

#include "familytree.h"

int traverse_ref(tree *node);

#endif 
